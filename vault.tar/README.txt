(base) ubuntu@ubunu2004:~/test/java-project$ java -cp target/java-project-1.0-SNAPSHOT.jar:lib/* br.lucio.jboss.vaultjbosstool.Main
WARNING: This tool will convert JKS to JCEKS if your keystore is not a JCEKS.
Keystore URL: (Ex: /tmp/new/a.keystore)
/opt/wildfly/bin/vault/vault.store
Keystore Password: (Ex: MASK-2CnDY1FriorSpKmoIGU5WR)
MASK-0FOV91/9idPaMgF3tkR9.V
Salt: (Ex: 12345678)
1234abcd
Interation: (Ex: 44)
50
Alias: (Ex: vault)
busa
Enc file directory: (Ex: /tmp/new)
/opt/wildfly/bin/vault/
Keystore password: union1234
Oct 08, 2020 1:59:22 PM org.picketbox.plugins.vault.PicketBoxSecurityVault init
INFO: PBOX00361: Default Security Vault Implementation Initialized and Ready
List of vault attributes:
Block: vb Attribute: password Pass: something

